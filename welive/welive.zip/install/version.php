<?php
	$WeLiveVersion = '4.0.0';
?>