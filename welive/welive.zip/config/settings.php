<?php if(!defined('ROOT')) die('Access denied.');

$_CFG = array();
$_CFG['BaseUrl'] = "http://localhost/welive/";
$_CFG['Actived'] = "1";
$_CFG['History'] = "1";
$_CFG['Record'] = "10";
$_CFG['Lang'] = "Auto";
$_CFG['SocketPort'] = "843";
$_CFG['Update'] = "2";
$_CFG['DeleteHistory'] = "0";
$_CFG['AutoOffline'] = "8";
$_CFG['KillRobotCode'] = "2T161F68";
$_CFG['Timezone'] = "+8";
$_CFG['DateFormat'] = "Y-m-d";
$_CFG['Title'] = "WeLive在线客服系统";
$_CFG['Welcome'] = "欢迎进入客服系统, 请咨询您的问题!";
$_CFG['Welcome_en'] = "Welcome! please post your question...";
$_CFG['AppVersion'] = "4.0.0";
$_CFG['AppName'] = "V2VMaXZl";
$_CFG['CopyrightUrl'] = "aHR0cDovL3d3dy53ZWVudGVjaC5jb20v";
$_CFG['Email'] = "xxxx@xxxxxx.com";
$_CFG['UseSmtp'] = "1";
$_CFG['SmtpHost'] = "smtp.163.com";
$_CFG['SmtpEmail'] = "xxxxxx@163.com";
$_CFG['SmtpPort'] = "25";
$_CFG['SmtpUser'] = "xxxxxxxx";
$_CFG['SmtpPassword'] = "xxxxxxxxx";

?>